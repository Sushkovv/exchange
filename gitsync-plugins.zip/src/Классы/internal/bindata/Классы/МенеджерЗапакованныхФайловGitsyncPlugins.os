﻿Функция ПолучитьИндексФайлов() Экспорт

	ИндексФайлов = Новый Соответствие;
	ИндексФайлов.Вставить("v8unpack_1.0.19.dll", "v8unpack_1_0_19_gitsync_plugins");
	ИндексФайлов.Вставить("v8unpack_1.9.dll", "v8unpack_1_9_gitsync_plugins");
	ИндексФайлов.Вставить("v8unpack.dll", "v8unpack_gitsync_plugins");
	ИндексФайлов.Вставить("v8unpack_2.0.0.dll", "v8unpack_2_0_0_gitsync_plugins");
	ИндексФайлов.Вставить("v8unpack_d.exe", "v8unpack_d_gitsync_plugins");
	ИндексФайлов.Вставить("cTool_1CD.exe", "cTool_1CD_gitsync_plugins");

	Возврат ИндексФайлов;

КонецФункции
